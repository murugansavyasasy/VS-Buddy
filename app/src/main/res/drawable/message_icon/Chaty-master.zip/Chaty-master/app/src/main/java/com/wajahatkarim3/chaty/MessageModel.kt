package com.wajahatkarim3.chaty

data class MessageModel (
    val message: String = "",
    val isMine: Boolean = true
)