# ABchat

## A whatsapp like Android chat application using Java, Android Studio & Firebase.

### Screenshots:-
<p float="left">
  
  <img src="https://user-images.githubusercontent.com/31586157/42641181-98f27b54-8611-11e8-8a46-f73ef542b499.png" width="240" text-color="#000000" height="400" hspace="20" /> 
  <img src="https://user-images.githubusercontent.com/31586157/42641897-3c455f28-8613-11e8-8c2f-8ff6fa53e213.png" width="240" height="400" hspace="20" /> 
  <img src="https://user-images.githubusercontent.com/31586157/42641963-68646658-8613-11e8-9ebc-b4d4eb9edeea.png" width="240" height="400" hspace="20" />
</p>
<br>
<p float="left">
  
  <img src="https://user-images.githubusercontent.com/31586157/42642076-a37c1cd6-8613-11e8-847e-e356f86d8044.png" width="240" height="400" hspace="20" /> 
  <img src="https://user-images.githubusercontent.com/31586157/42642220-fe96b216-8613-11e8-8309-355d6262797b.png" width="240" height="400" hspace="20" /> 
  <img src="https://user-images.githubusercontent.com/31586157/42642343-4986160e-8614-11e8-8222-2d42ca90cd0d.png" width="240" height="400"
  hspace="20"/>
</p>
