package com.wajahatkarim3.chaty

data class UserModel (
    val uid: String = "",
    val name: String = "",
    var status: String = "",
    val photoUrl: String = ""
)